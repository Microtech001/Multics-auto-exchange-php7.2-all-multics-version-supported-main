<footer class="footer section section--footer">
	<div class="section__layout"> </div>
</footer>
<script src="dist/js/app.min.js"></script>
</body>

</html>