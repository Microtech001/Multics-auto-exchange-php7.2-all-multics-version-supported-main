<?php
require("config.php");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $nameserver; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="all,index,follow" />

<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />

<link href="styles/style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.coda-slider-2.0.js"></script>
<script type="text/javascript" src="js/jquery.form_validation.js"></script>
<script type="text/javascript" src="js/contact_form.js"></script>

<script type="text/javascript">

$().ready(function() {
 $("#coda-slider-1").codaSlider();
});

</script>

<script src="https://cdn.adf.ly/js/display.js"></script> 
<!--
[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]
-->
</head>
<body>

<div id="container">

<div id="top_wrap">

<div id="top_menu">

<div class="ukusa"></div>
<!-- end class ukusa -->
<!-- end class email -->
<div class="phone">

Skype: <a href="Skype:<?php echo $skype; ?>?add" title="Skype"><?php echo $skype; ?></a>

</div>
<!-- end class phone -->

<div class="login">

<a href="contact.php" title="SUPPORT">SUPP</a></div>
<!-- end class login -->

<div class="livechat">

<a href="Skype:<?php echo $skype; ?>?add" title="Live Chat">Live Chat</a></div>
<!-- end class livechat -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end id top_menu -->

</div><!-- end id top_wrap -->

<div id="header_wrap">

<div id="header">

<div class="logo">

<a href="index.php" title="<?php echo $nameserver; ?>"><?php echo $nameserver; ?></a></div>
<!-- end class logo -->

<div id="midmenu">

<ul>
<li><a href="index.php" title="Home" class="home">Home</a></li>
<li class="nobg"><a href="contact.php" title="Contact" class="contactus">Contact </a></li>
</ul>
</div><!-- end id midmenu -->

<div class="clear"></div><!-- end class clear -->

<nav id="dropdown">

<ul>
<li class="active"><a href="#" title="text link"></a></li>
<li><a href="index.php" title="welcome to SERVER EXCHANGE">WELCOME</a></li>
<li><a href="cache.php" title="EXCHANGE CACHE">CACHE</a></li>
<li class="menu-drop"><a href="cccam.php" title="EXCHANGE CCCAM">CCCAM</a></li>
<li><a href="magcamd.php" title="EXCHANGE MGCAMD">MGCAMD</a></li>
<li><a href="profile.php" title="PROFILE">PROFILE</a></li>
<li><a href="tools.php" title="TOOLS">TOOLS</a></li>
<li><a href="contact.html" title="Support">SUPP</a></li>
</ul>

</nav><!-- end id dropdown -->

<div class="clear"></div><!-- end class clear -->

</div>
</div><!-- end id header -->

</div><!-- end id header_wrap -->

<div id="mainbg">

<div class="wrapper">








<div class="content_top"></div><!-- end class content_top -->

<div id="content_area">

<div id="right_sidebar">

<div class="right_column_list">
  <ul class="right_list"><li class="email"><a href="mailto:<?php echo $mail; ?>" title="mail"><?php echo $mail; ?></a></li>
</ul>

</div><!-- end class right_column_list -->

</div><!-- end id right_sidebar -->

<div id="left_content">

<h1>
Contact-us
</h1>

<form action="" method="post" id="register-form" novalidate="novalidate">

<h2><span id="result_box" lang="fr">Contact us via skype or via mail</span></h2>

<div id="form-content">

<fieldset>


<div class="fieldgroup top_field">

<h3><center><br>Skype: <a href="Skype:<?php echo $skype; ?>?add" title="Skype"><?php echo $skype; ?></a></center></h3>
<h3><center><br>Mail: <a href="mailto:<?php echo $mail; ?>" title="mail"><?php echo $mail; ?></a></center></h3>
<br>

</fieldset>

</div><!-- end id form-content -->

<div class="fieldgroup">

<p><span id="result_box" lang="fr"></span><a href="./index.php" title="<?php echo $nameserver; ?>"><span id="result_box" lang="fr">BACK HOME</span></a>.</p>

</div><!-- end class fieldgroup -->

</form>

</div><!-- end id left_content -->

</div><!-- end id content_area -->

<div class="content_bottom"></div><!-- end class content_bottom -->













<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id mainbg -->

<div id="top_footer">

<div class="wrapper">

<div class="wrapper">

<div class="footerlt">

<div class="footer_column">



<div class="footer_column">

<h2>Support </h2>

<ul>
<li><a href="contact.php" title="CONTACT"><span id="result_box" lang="fr">CONTACT</span></a></li>
</ul>

</div><!-- end class footer_column -->
<!-- end class footer_column -->
<div class="clear"></div><!-- end class clear -->
<!-- end class socialmedia -->
<div class="payment"></div><!-- end class payment -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id top_footer -->

<div id="bottom_footer">

<div class="wrapper">
  
<div class="left_bottom">

<ul>
<ul>
<li>
Copyright &copy; <a href="contact.php" title="Contact">Contact</a></li>
<li>
<a href="Skype:vitruvedz?add" title="SKYPE">BY VITRUVEDZ</a></li>
</ul>
</div><!-- end class left_bottom -->

<div class="right_bottom">

<p><a href="http://www.lkgraph.com" title="text link">'</a></p>

</div><!-- end class right_bottom -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper --> 

</div><!-- end id bottom_footer -->

</div><!-- end id container -->
</body>
</html>