$('input#host').on('focusout', function() {
    var host = $('input#host').val();
    if ($.trim(host) != '') {
         $.post('ip.php', {host: host}, function(data) {
            $('input[name="ip"]').val(data);
         
        })
     
    };

});