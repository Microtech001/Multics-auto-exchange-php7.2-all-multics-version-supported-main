<?php
require("config.php");


include 'hide.php';


include 'hide.php';


include 'hide.php';


include 'hide.php';


?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html" />
  <meta charset="UTF-8">
  <title>Cache to cache auto exchanger | Cline.PK</title>
  <meta name="Keywords" content="best cache exchanger, multics cache exchanger, cahces exchanger,multics auto exchanger tool">
  <meta name="theme-color" content="#2c7dbc">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <link rel="stylesheet" href="dist/css/app.min.css">
  <link rel="icon" type="image/x-icon" href="favicon.png" />
<link type="text/css" media="screen" rel="stylesheet" href="awwwards.html" />
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
input[type=number] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

</style>
</head>
<body>
  <svg style="visibility: hidden; position: absolute; top: -1000px; left: -1000px;">
    <linearGradient id="svgGradient" x1="0%" y1="50%" x2="0%" y2="0%" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#2c7dbc"/>
      <stop offset="100%" stop-color="#7cccc5"/>
    </linearGradient>
  </svg>

  <header class="header section section--header">
    <div class="section__layout">
      <a href="index.php" class="header__logo">
        <span data-aos="fade-right" data-aos-delay="50">Cline.PK</span>
        <span data-aos="fade-right" data-aos-delay="75">Exchanger</span>
      </a>
      <div class="nav-icon">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <nav class="header__nav">
        <div class="header__nav-layout" data-aos="fade-down" data-aos-delay="75">
          <ul class="header__nav-links">
            <li><a href="/ex">Home</a></li>
            <li><a href="/ex/tools.php">Tools</a></li>
            <li><a href="/ex/contact.php">Contact US</a></li>
          </ul>
          <a href="http://clinepk.cf" class="button button--outline button--color-white button--size-m">
            <span>Panel</span>
          </a>
        </div>
      </nav>
    </div>
  </header>
  <main>
<section class="section section--home section--full-height">
  <div class="home-circle" data-aos="fade-left" data-aos-delay="50"></div>
  <div class="section__layout">
    <div class="section__content">
      <h1 data-aos="fade-up"  data-aos-delay="50">Cache Cline MGccam Nline Exchanger</h1>
      <p  data-aos="fade-up"  data-aos-delay="100">
       Best Cline, CCcam, Cahces, Mgcamd or Newcamd Lines Auto Exchager Tool.
    
      </p>

     
    </div>
    <div class="home-image" data-aos="fade-left" data-aos-delay="150">
      <svg><use xlink:href="dist/svg/symbols.svg#message-plane"/></svg>
    </div>
  </div>
</section>

<section class="section section--features" id="features-anchor">
  <div class="section__layout" data-aos="fade-up" data-aos-offset="-100" data-aos-delay="200">

    <div class="grid">
      <div class="grid__cell">
        <div class="section__content" data-aos="fade-up">
          <h2>
           Cache Exchanging Reception
          </h2>
          <p>
       Add your cache peer if it will valid then you will receive  our cache in this page.</p>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
function eventHandler() {
var host = $('input#ip').val();
var CheckIP = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;

INPUT_CONTENT = '';

polling = function() {
  if (INPUT_CONTENT != document.getElementById('ip').value)
    eventHandler();

  INPUT_CONTENT = document.getElementById('ip').value;

  setTimeout(polling, 500);
};
</script>


<form method="post">
<center><br><b><input type="text" name="host" placeholder="Domain or IP" id="host" value="" pattern="^[a-z.A-Z0-9]+$" required>  
 <input id="ip" type="text" placeholder="Valid IP" name="ip" DISABLED>

<script type="text/javascript" src="styles/ip.js"></script>
<script type="text/javascript">
  polling();
 document.getElementById('ip').focus();
</script>

<input type="number" placeholder="Port" name="port" pattern="^[0-9]+$" required></b></br></center>

<center><br>


      <input type="submit">



</b></br></center>
</form>
</body>


<?php
if (isset($_POST["host"]) && !empty($_POST["host"]) &&  isset($_POST["port"]) &&  isset($_POST["port"]) ) {
$dateadd = date('Y-m-d', strtotime("+0 days"));
$handle = fopen($cfgcache,'a');
fwrite($handle, 'CACHE PEER: '.$_POST["host"].' '.$_POST["port"]. "1 \n");
fclose($handle);
echo '<br/><br/><hr/><br/><center><br><b><font color="orange">Your Cache Is Ready...</font></b></br></center>
<input type="text" class="form-control" value="CACHE PEER: '.$url.' '.$portcache.' 1" id="prince"></input> 
<input type="submit" value="Copy My Cache" onclick="myFunction()">
<div style="display:none;">'.$dateadd."</div> \n";
}
?>
<?php

// filename
$filename = $cfgcache;

$text = array_unique(file($filename));

$f = @fopen($filename,'w+');
if ($f) {
fputs($f, join('',$text));
fclose($f);
}

?>


<script>
function myFunction() {
  var copyText = document.getElementById("prince");
  copyText.select();
  document.execCommand("copy");
}
</script>


        </div>
      </div>
    </div>
  </div>
</section>


</main>
<footer class="footer section section--footer">
  <div class="section__layout">

    <div class="grid grid--middle grid--flush" id="contacts-footer-info">
      <div class="1/2--tablet grid__cell footer__title">
        <h2>
          Have Any Queston Or Need Support? <br>
          Feel Free Touch Us.
        </h2>
      </div>
      <div class="1/2--tablet grid__cell">
        <div class="footer__contacts">
          <div class="section__line" data-aos="scale-down" data-aos-delay="50" data-aos-offset="100"></div>
          <div class="footer__contact-card">
            <h4>E-Mail</h4>
            <a href="mailto:support@cline.pk">Support@cline.pk</a>
          </div>
          <div class="footer__contact-card">
            <h4>Call/SMS/Whatsapp</h4>
            <a href="tel:+923077401050">+92 307 7401050</a>
          </div>
        </div>
      </div>
    </div>

    <div class="footer__bottom grid grid--middle grid--flush">
      <div class="1/4--tablet grid__cell">
        <a href="https://cline.pk">Cline.PK</a>
      </div>
      <div class="2/4--tablet grid__cell">
        <p>
          COPYRIGHT 2018. ALL RIGHTS RESERVED.<br>Designing And Development By <a href="https://hostings.pk">Hostings.PK</a>
        </p>
      </div>
      <div class="1/4--tablet grid__cell">
        <button>Muhammad Ashan</button>
        <button>03077401050</button>
      </div>
    </div>
  </div>
</footer>
<script src="dist/js/app.min.js"></script>
</body>
</html>
