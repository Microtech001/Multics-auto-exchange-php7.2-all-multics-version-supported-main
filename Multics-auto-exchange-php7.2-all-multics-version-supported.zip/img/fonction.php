<?php
/**
//writetoLog
**/
function writetoLog($text)
{
	global $fh;
	echo ("<pre>" .$text ."<br />\n");
	//fwrite($fh, $text ."\n");
}
/**
//get between
**/
function get_between($content, $start, $end){
	$r = explode($start, $content);
	if (isset($r[1])){
		$r = explode($end, $r[1]);
		return $r[0];
	}
	return '';
}
/**
//getURL response Code
**/
function getURL_responseCode($url, $user, $pass)
{
    	$ch = curl_init();
    	$userAgent = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5';

    	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    	curl_setopt($ch, CURLOPT_URL, $url);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
    	//curl_setopt($ch, CURLOPT_HEADER, 1);
    	curl_setopt($ch, CURLOPT_USERPWD, $user . ":" . $pass);

    	$data = curl_exec($ch);
	$info = curl_getinfo($ch);
        curl_close($ch);

	if (empty($info['http_code'])) {
        	$data3="error";
    	} else {
        	// load the HTTP codes
        	$data3=$info['http_code'];
	}
	//echo $data3;
    	return $data3;
}

/**
////getURL response
**/
	function getURL_response($url, $user, $pass) {
    $ch = curl_init();
    $userAgent = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5';

    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
	curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/xml')); 

    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_USERPWD, $user . ":" . $pass);

    $data = curl_exec($ch);

	   
	
	/*
	
    if (curl_errno($ch)> 0){
        die('There was a cURL error: ' . curl_error($ch));
    } else {
        curl_close($ch);
*/



        return $data;
    }
/**
////get profiles & ports from multics
**/
function get_profiles_ports($url,$port,$user,$pass) {
$data = getURL_response($url .":" .$port ."/profiles",$user,$pass);
			$start = '<table class=maintable width=100%%>';
			$end = '<tr class=alt3><td align=right>Total';
			$data = get_between($data, $start, $end);
$rows = preg_split('/<tr id/', $data);
array_shift($rows);
			foreach($rows as $row) {
$lo = str_replace('="Row','<tag>', $row);
$lol = str_replace('pid=','</tag>', $lo);
$ndo = str_replace('</span></td></tr>','</option>', $lol);
$fg = preg_replace("%<tag>.*?</tag>%", '<tag>', $ndo);
$ndof = str_replace('right;">','', $fg);
$no = str_replace('</b> ','', $ndof);
$po = str_replace(' <span style=','<option>', $no);
$fg1 = preg_replace("%<option>.*?</option>%", ']</option>', $po);
$ndof2 = str_replace('">','</tag>', $fg1);
$fgl = preg_replace("%<tag>.*?</tag>%", '<option value="', $ndof2);
$ndof3 = str_replace('</a></td><td align=center>','<tag>', $fgl);
$ndof4 = str_replace('</span></td><td><b>','</tag>', $ndof3);
$fgl4 = preg_replace("%<tag>.*?</tag>%", '" > CAID [', $ndof4);
$ndof412 = str_replace(':',']  PROVIDER  [', $fgl4);
echo("$ndof412");
}
}
/**
////generatePassword
**/
function generatePassword ($length = 5) 
{ 
  // start with a blank password 
  $genpassword = ""; 
  // define possible characters 
  $possible = "0123456789";  
  // set up a counter 
  $i = 0;  
  // add random characters to $password until $length is reached 
  while ($i < $length) {  
    // pick a random character from the possible ones 
    $char = substr($possible, mt_rand(0, strlen($possible)-1), 1); 
    // we don't want this character if it's already in the password 
    if (!strstr($genpassword, $char)) {  
      $genpassword .= $char; 
      $i++; 
    } 
  } 
  // done! 
  return $genpassword; 
}  








/**
//check_mgcamd_stats
**/
function check_mgcamd_stats($url, $port, $user, $pass, $version ,$portmgcamd ,$dateadd ,$cfgmgcamd ,$keys)
{
	$data = '';
	if ($version == "r81") {
		$data = getURL_response($url .":" .$port ."/servers?type=all&list=all", $user, $pass);
writetoLog("<br><hr><br><b>Checking MGcamd line: <font color='red'>N: ".$_POST["host"]." ".$_POST["ports"]." ".$_POST["users"]." ".$_POST["passs"]." <br> ".$_POST["key"]."</font> </b>");
	} 
$start = '<table class=maintable width=100%>';
	$end = '</html>';
	$data = get_between($data, $start, $end);
	$rows = preg_split('/<tr id/',$data);
$row = end($rows); 
$no = str_replace('="Row','<tag>', $row);
$po = str_replace('</td><td class="','</tag>', $no);
$fg = preg_replace("%<tag>.*?</tag>%", '', $po);
$so = str_replace('</span></td></tr>
</table></div></body>','>>', $fg);
$so1 = str_replace('<pre>',' ', $so);
$so2 = str_replace('</pre>',' ', $so1);
$fg1 = preg_replace("%<.*?>%", '', $so);
$so1 = str_replace('">','<<', $fg1);
$fg11 = preg_replace("%<<.*?>>%", '', $so1);
$dateadd = date('Y-m-d', strtotime("+0 days"));

if ($fg11 == "online") {
addmgusertoConfig($cfgmgcamd);
writetoLog("<br><div style='border: dashed 1px green; padding: 30px;'><B>Your MGcamd Line Status : <font color='green'> Online</font></B></div>");

writetoLog("<style> .hideforum {display:none;} </style><B>Your MGcamd Line is Ready.<br></B>");
writetoLog("<br><input type='text' value='N: ".$url." ".$portmgcamd." ".$_POST["user11"]." ".$_POST["pass11"]." ".$keys."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");
		}
if ($fg11 == "busy") {
addmgusertoConfig($cfgmgcamd);
writetoLog("<style> .hideforum {display:none;} </style><B>Your MGcamd Line is Ready.<br></B>");
writetoLog("<br><input type='text' value='N: ".$url." ".$portmgcamd." ".$_POST["user11"]." ".$_POST["pass11"]." ".$keys."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");
		}
if ($fg11 == "offline") {
removeLastLineFromConfig($cfgmgcamd);		
writetoLog("<br><br><div style='border: dashed 1px red; padding: 30px;'><B>Your MGcamd Line Status : <font color='red'> Offline</font></B></div>");
}
}

/**
//function remove Last Line From Config
**/
function addmgusertoConfig($cfgmgcamd)
{
$dateadd = date('Y-m-d', strtotime("+0 days"));
$handle = fopen($cfgmgcamd,'a');
fwrite($handle, 'MG: '.$_POST["user11"].' '.$_POST["pass11"].' # '.$_POST["skype"].' '.$_POST["host"].' '.$dateadd." # \n");
fclose($handle);
}
/**
//function remove Last Line From Config
**/
function addlinetoConfig($cfgmgcamd)
{
$dateadd = date('Y-m-d', strtotime("+0 days"));
$handle = fopen($cfgmgcamd,'a');
fwrite($handle, 'N: '.$_POST["host"].' '.$_POST["ports"].' '.$_POST["users"].' '.$_POST["passs"].' '.$_POST["key"]." \n");
fclose($handle);
}
/**
//function remove Last NLine From Config
**/
function removeLastLineFromConfig($cfgmgcamd)
{
// load the data and delete the line from the array 
$lines21 = file($cfgmgcamd); 
$last = sizeof($lines21) - 1 ; 
unset($lines21[$last]); 
// write the new data to the file 
$fp = fopen($cfgmgcamd, 'w'); 
fwrite($fp, implode('', $lines21)); 
fclose($fp); 
}

/**
//check_nline_profile_stats
**/
function check_lines_stats($url, $port, $user, $pass, $version ,$portmgcamd ,$dateadd ,$cfgmgcamd ,$keys ,$vl)
{
	$data = '';
	if ($version == "r81") {
		$data = getURL_response($url .":" .$port ."/servers?type=all&list=all", $user, $pass);
writetoLog("<br><hr><br><b>Checking Your Nline Status: <font color='red'>N: ".$_POST["host"]." ".$_POST["ports"]." ".$_POST["users"]." ".$_POST["passs"]." ".$_POST["key"]."</font> </b>");
	} 
$start = '<table class=maintable width=100%>';
	$end = '</html>';
	$data = get_between($data, $start, $end);
	$rows = preg_split('/<tr id/',$data);
$row = end($rows); 
$no = str_replace('="Row','<tag>', $row);
$po = str_replace('</td><td class="','</tag>', $no);
$fg = preg_replace("%<tag>.*?</tag>%", '', $po);
$so = str_replace('</span></td></tr>
</table></div></body>','>>', $fg);
$so1 = str_replace('<pre>',' ', $so);
$so2 = str_replace('</pre>',' ', $so1);
$fg1 = preg_replace("%<.*?>%", '', $so);
$so1 = str_replace('">','<<', $fg1);
$fg11 = preg_replace("%<<.*?>>%", '', $so1);
$dateadd = date('Y-m-d', strtotime("+0 days"));

if ($fg11 == "online") {
addmgusernewcamdtoConfig($cfgmgcamd);
writetoLog("<br><div style='border: dashed 1px green; padding: 30px;'><B>Your NLine Status : <font color='green'> Online</font></B></div>");
writetoLog("<style> .hideforum {display:none;} </style><B>Your NLine is Ready.<br></B>");
writetoLog("<br><input type='text' value='N: ".$url." ".$portmgcamd." ".$_POST["user11"]." ".$_POST["pass11"]." ".$keys."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");
		}
if ($fg11 == "busy") {
addmgusernewcamdtoConfig($cfgmgcamd);
writetoLog("<B>NLINE: <font color='GREEN'>ONLINE</font> CHECKED IN <font color='red'>".$dateadd."</font></B>");
writetoLog("<style> .hideforum {display:none;} </style><B>Your NLine is Ready.<br></B>");
writetoLog("<br><input type='text' value='N: ".$url." ".$portmgcamd." ".$_POST["user11"]." ".$_POST["pass11"]." ".$keys."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");
		}
if ($fg11 == "offline") {
removeLastLineFromConfig($cfgmgcamd);		
writetoLog("<br><br><div style='border: dashed 1px red; padding: 30px;'><B>Your Nline Status : <font color='red'> Offline</font></B></div>");
}
}
//add user newcamd
function addmgusernewcamdtoConfig($cfgmgcamd)
{
$dateadd = date('Y-m-d', strtotime("+0 days"));
$handle = fopen($cfgmgcamd,'a');
fwrite($handle, 'MG: '.$_POST["user11"].' '.$_POST["pass11"].' { profiles='.$_POST["vl"].'; } # '.$_POST["skype"].' '.$_POST["host"].' '.$dateadd." # \n\n");
fclose($handle);
}

/**
//function add cline
**/
function addclinetoConfig($cfgclines)
{
$dateadd = date('Y-m-d', strtotime("+0 days"));
$handle = fopen($cfgclines,'a');
fwrite($handle, 'C: '.$_POST["host"].' '.$_POST["ports"].' '.$_POST["users"].' '.$_POST["passs"]." \n\n");
fclose($handle);
}
/**
//function remove Last NLine From Config
**/
function removLastcLineFromConfig($cfgclines)
{
// load the data and delete the line from the array 
$lines21s = file($cfgclines); 
$last1 = sizeof($lines21s) - 1 ; 
unset($lines21s[$last1]); 
// write the new data to the file 
$fp = fopen($cfgclines, 'w'); 
fwrite($fp, implode('', $lines21s)); 
fclose($fp); 
}
/**
//function  check cline stats
**/
function check_cline_stats($url, $port, $user, $pass, $version ,$portcccam ,$dateadd ,$cfgclines)
{
	$data = '';
	if ($version == "r81") {
		$data = getURL_response($url .":" .$port ."/servers?type=all&list=all", $user, $pass);
writetoLog("<br><hr><br><b>Checking Your Cline Status: <font color='red'>C: ".$_POST["host"]." ".$_POST["ports"]." ".$_POST["users"]." ".$_POST["passs"]."</font> </b>");
	} 
	$start = '<table class=maintable width=100%>';
	$end = '</html>';
	$data = get_between($data, $start, $end);
	$rows = preg_split('/<tr id/',$data);
foreach($rows as $row) {
$searchfor = strval($_POST['host']).':'.strval($_POST['ports']);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if(preg_match_all($pattern, $row, $matches)){
$lines = implode($matches[0]);
$no = str_replace('="Row','<tag>', $lines);
$po = str_replace('</td><td class="','</tag>', $no);
$fg = preg_replace("%<tag>.*?</tag>%", '', $po);
$so = str_replace('</span></td></tr>','>>', $fg);
$so1 = str_replace('<pre>',' ', $so);
$so2 = str_replace('</pre>',' ', $so1);
$fg1 = preg_replace("%<.*?>%", '', $so);
$so1 = str_replace('">','<<', $fg1);
$fg11 = preg_replace("%<<.*?>>%", '', $so1);

if ($fg11 == "offline") {
removLastcLineFromConfig($cfgclines);
writetoLog("<br><br><div style='border: dashed 1px red; padding: 30px;'><B>Your Cline Status : <font color='red'>Offline</font></B></div>");

		}

if ($fg11 == "online") {
addFlinetoConfig($cfgclines);
writetoLog("<style> .hideforum {display:none;} </style><br><div style='border: dashed 1px green; padding: 30px;'><B>Your CLine Status : <font color='green'> Online</font></B></div>");
writetoLog("<B>Your CLine is Ready.<br></B>");
writetoLog("<br><input type='text' value='C: ".$url." ".$portcccam." ".$_POST["user11"]." ".$_POST["pass11"]."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");

		}
if ($fg11 == "busy") {
addFlinetoConfig($cfgclines);

writetoLog("<style> .hideforum {display:none;} </style><B>Status: <font color='DARKGREEN'>ONLINE</font></B>");
writetoLog("<B>YOUR're redy CLINE IS: <font color='green'>C: ".$url." ".$portcccam." ".$_POST["user11"]." ".$_POST["pass11"]."</font></B>");
writetoLog("<br><input type='text' value='C: ".$url." ".$portcccam." ".$_POST["user11"]." ".$_POST["pass11"]."' id='prince'>");
writetoLog("<input type='submit' onclick='myFunction()' value='Copy Line'>");
		}
 
}
} 
}
/**
//function add fline
**/
function addFlinetoConfig($cfgclines)
{
$handle = fopen($cfgclines,'a');
fwrite($handle, 'F: '.$_POST["user11"].' '.$_POST["pass11"].' # '.$_POST["skype"].' '.$_POST["host"].' '.$dateadd." # \n\n");
fclose($handle);
}
?>
