<?php
// ports profiles
$skype = "clinepk.cf";   // your skype id
$nameserver = "clinepk.cf";  // server name
$mail = "support@cline.pk"; // your email
$url = "clinepk.cf"; // your host
$port = "7700"; // http port
$user = "admin"; // http user
$pass = "admin@786"; // http pass
$version = "r81"; // mcs version // dont tuch i will try with all version of multics

// PORT CCCAM/MGCAMD/CACHE
$portcache = "3467";  // your cache port
$portcccam = "21000"; // your cccam port
$portmgcamd = "58000"; // your mgcamd port
$keys = "01 02 03 04 05 06 07 08 09 10 11 12 13 14"; // your key

// cfg files
$cfgclines = "/var/etc/files/EXCccam.cfg";// cfg cccam file (clines-flines)
$cfgmgcamd = "/var/etc/files/EXMGcamd.cfg";// cfg mgcamd file (mg lines-Nlines)
$cfgcache = "/var/etc/files/EXcache.cfg";// cfg cache file (cache)

?>