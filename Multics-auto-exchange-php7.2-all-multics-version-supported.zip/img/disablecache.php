<?php

##### MULTICS BAD CACHE PEER BLOCK SCRIPT BY TOMMYS (MULTICS.INFO) - TESTED ON R81 ONLY####
##### IF RE-SHARING THIS SCRIPT, PLEASE KEEP THE CREDITS AND BE FAIR!!###

### DO NOT EDIT### 
ob_implicit_flush(1);
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 300); //300 seconds = 5 minutes
global $fh;
//$fh = fopen("DisableCache.log", 'w') or die("Can't create file");
### DO NOT EDIT ### 

$url= strval($_POST['urls']);
$port= strval($_POST['ports']);
$user= strval($_POST['users']);
$pass= strval($_POST['passs']);
$version= strval($_POST['versions']);

##### START - ADD MULTICS INFO HERE ####

check_cacheex_stats($url, $port, $user, $pass, $version);


##### END - ADD MULTICS INFO HERE ####


### DO NOT EDIT ANYTHING BELOW### 

function check_cacheex_stats($url, $port, $user, $pass, $version)
{


//	writetoLog("###Checking URL: " .$url." Port: " .$port." ####");
	$data = '';
	if ($version == "r81") {
		$data = getURL_response($url .":" .$port ."/cache?id=0&list=active", $user, $pass);
writetoLog("<b>Checking URL: <font color='red'>" .$url."</font> Port: <font color='red'>" .$port."</font> </b>");
writetoLog("<b><font color='green'>Connected to Server</font></b>");
	} else if ($version == "r70") {
		$data = getURL_response($url .":" .$port ."/cache?list=active", $user, $pass);
writetoLog("<b>Checking URL: <font color='red'>" .$url."</font> Port: <font color='red'>" .$port."</font> </b>");
writetoLog("<b><font color='green'>Connected to Server</font></b>");

} else if ($version == "r77") {
		$data = getURL_response($url .":" .$port ."/cache?list=active", $user, $pass);
writetoLog("<b>Checking URL: <font color='red'>" .$url."</font> Port: <font color='red'>" .$port."</font> </b>");
writetoLog("<b><font color='green'>Connected to Server</font></b>");
	}

	//writetoLog("Connected to Server");

	$start = '<table class=maintable width=100%>';
	$end = '<tr class=alt3>';
	$data = get_between($data, $start, $end);
	$rows = preg_split('/<tr id="Row/', $data);
	array_shift($rows);

	foreach($rows as $row) {
		$cols = preg_split('/><td/', $row);
		$peer = preg_replace('/:/', ' ', ltrim(rtrim(trim(substr(strip_tags($cols[1]), 1)))));
		$regex1 = preg_replace('/:/', ' ', ltrim(rtrim(trim(substr(($cols[1]), 1)))));

		$regexpHREF = "<a\s[^>]*href=(\"??)([^\" >]*?)\\1[^>]*>(.*)<\/a>";
		$matches = array();
		preg_match_all("/$regexpHREF/siU", $regex1, $matches);

		$errors = array_filter($matches);

		if (!empty($errors)) {
			$id=str_replace("'","",$matches[2][0]);
		} else {
			$id="NA";
		}
if ($version == "r81") {

		if (array_key_exists(11, $cols)) {
			$program = ltrim(rtrim(trim(substr(strip_tags($cols[11]), 1))));
		}
		}
if ($version == "r70") {

		if (array_key_exists(10, $cols)) {
			$program = ltrim(rtrim(trim(substr(strip_tags($cols[10]), 1))));
		}
		}
if ($version == "r77") {

		if (array_key_exists(9, $cols)) {
			$program = ltrim(rtrim(trim(substr(strip_tags($cols[9]), 1))));
		}
		}        

		if(empty($program)) {
			if ($id !="NA") {
				$link = getURL_responseCode($url .':' .$port.$id.'&action=disable',$user,$pass);
				echo '<b>CACHE PEER: '.$peer ." <B><font color='red'>BLOCKING</font></b> (HTTP Status: <font color='red'>" .$link ."</font>) </b><br />\n";
			}
		}
	}
}


function get_between($content, $start, $end)
{
	$r = explode($start, $content);

	if (isset($r[1])){
		$r = explode($end, $r[1]);
		return $r[0];
	}
	return '';
}


function writetoLog($text)
{
	global $fh;
	echo ("<pre>" .$text ."<br />\n");
	//fwrite($fh, $text ."\n");
}


function getURL_responseCode($url, $user, $pass)
{
    	$ch = curl_init();
    	$userAgent = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5';

    	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    	curl_setopt($ch, CURLOPT_URL, $url);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
    	//curl_setopt($ch, CURLOPT_HEADER, 1);
    	curl_setopt($ch, CURLOPT_USERPWD, $user . ":" . $pass);

    	$data = curl_exec($ch);
	$info = curl_getinfo($ch);
        curl_close($ch);

	if (empty($info['http_code'])) {
        	$data3="error";
    	} else {
        	// load the HTTP codes
        	$data3=$info['http_code'];
	}
	//echo $data3;
    	return $data3;
}

function getURL_response($url, $user, $pass)
{
	$ch = curl_init();
  	$userAgent = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5';

    	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    	curl_setopt($ch, CURLOPT_URL, $url);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
	curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/xml')); 

    	curl_setopt($ch, CURLOPT_HEADER, 0);
    	curl_setopt($ch, CURLOPT_USERPWD, $user . ":" . $pass);

    	$data = curl_exec($ch);

   	if (curl_errno($ch)> 0){
		echo "URL: ".$url;
		die('There was a cURL error: ' . curl_error($ch));
    	} else {
        	curl_close($ch);
	}

	return $data;
}
?>
