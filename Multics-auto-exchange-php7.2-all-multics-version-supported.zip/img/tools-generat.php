<?php
require("config.php");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $nameserver; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="all,index,nofollow" />
<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />

<link href="styles/style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.coda-slider-2.0.js"></script>
<script type="text/javascript" src="js/jquery.form_validation.js"></script>
<script type="text/javascript" src="js/contact_form.js"></script>

<script type="text/javascript">

$().ready(function() {
 $("#coda-slider-1").codaSlider();
});

</script>

<script src="https://cdn.adf.ly/js/display.js"></script> 
<!--
[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]
-->
</head>
<body>
<!--
This free web hosting template is provided by http://lkgraph.com/
and is released and licensed under the
Creative Commons Attribution 3.0 Unported License (http://creativecommons.org/licenses/by/3.0/).
This means that you are free to download this template for any personal and commercial purpose as long as you
keep the text links in the bottom right footer as they are.
-->
<div id="container">

<div id="top_wrap">

<div id="top_menu">

<div class="ukusa"></div>
<!-- end class ukusa -->
<!-- end class email -->
<div class="phone">

Skype: <a href="Skype:<?php echo $skype; ?>?add" title="Skype"><?php echo $skype; ?></a>
</div>
<!-- end class phone -->

<div class="login">

<a href="contact.php" title="SUPPORT">SUPP</a></div>
<!-- end class login -->

<div class="livechat">

<a href="Skype:<?php echo $skype; ?>?add" title="Live Chat">Live Chat</a></div>
<!-- end class livechat -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end id top_menu -->

</div><!-- end id top_wrap -->

<div id="header_wrap">

<div id="header">

<div class="logo">

<a href="index.php" title="<?php echo $nameserver; ?>"><?php echo $nameserver; ?></a></div>
<!-- end class logo -->

<div id="midmenu">

<ul>
<li><a href="index.php" title="Home" class="home">Home</a></li>
<li class="nobg"><a href="contact.php" title="Contact" class="contactus">Contact </a></li>
</ul>
</div><!-- end id midmenu -->

<div class="clear"></div><!-- end class clear -->

<nav id="dropdown">

<ul>
<li class="active"><a href="#" title="text link"></a></li>
<li><a href="index.php" title="welcome to SERVER EXCHANGE">WELCOME</a></li>
<li><a href="cache.php" title="EXCHANGE CACHE">CACHE</a></li>
<li class="menu-drop"><a href="cccam.php" title="EXCHANGE CCCAM">CCCAM</a></li>
<li><a href="magcamd.php" title="EXCHANGE MGCAMD">MGCAMD</a></li>
<li><a href="profile.php" title="PROFILE">PROFILE</a></li>
<li><a href="tools.php" title="TOOLS">TOOLS</a></li>
<li><a href="contact.php" title="Support">SUPP</a></li>
</ul>

</nav><!-- end id dropdown -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end id header -->

</div><!-- end id header_wrap -->



<div class="slidernavcon coda-nav">

<div class="wrapper">

<ul class="slidernav">

<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->
 
</div><!-- end classes slidernavcon coda-nav -->
 
</div><!-- end class coda-slider-wrapper -->
  
</div><!-- end class bannercon -->

<div id="mainbg">

<div class="wrapper">
<h1>USER GENERATOR TOOL</h1>

<br>
</br>
<form method="post">
<b><center>NUMBER OF USERS: <input type="text" name="number" size="20"/>
HOST: <input type="text" name="host" size="20"/>
PORT: <input type="text" name="port" size="20"/></center></b>
<br>
</br>
<b><center>Username length : <input type="text" name="userlength" size="20" value="7"/>
Password length: <input type="number" name="passlength" size="20" value="7"/></center></b>
<br>
</br>
<center><input type = "submit" value = "Generate"></center>
</form>
<br>
</br>
<?php

if (isset($_POST["number"]) && !empty($_POST["number"]) &&  isset($_POST["host"]) &&  isset($_POST["host"]) &&  isset($_POST["port"]) &&  isset($_POST["port"]) &&  isset($_POST["passlength"]) &&  isset($_POST["passlength"]) &&  isset($_POST["userlength"]) && !empty($_POST["userlength"])) {

function random( $length )
{
	// Set allowed chars
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
	// Create username
	$username = "";
	for ( $i = 0; $i < $length; $i++ )
	{
		$username .= $chars[mt_rand(0, strlen($chars))];
	}
	return $username;
}


// Set some variables
$ports= strval($_POST['port']);
$hosts= strval($_POST['host']);
$number_of_users = strval($_POST['number']);
$min_username_length = strval($_POST['userlength']);;
$max_username_length = strval($_POST['userlength']);;
$min_password_length = strval($_POST['passlength']);;
$max_password_length = strval($_POST['passlength']);;

// Create user array
$users = array();

// Create usernames
for ( $i = 0; $i < $number_of_users; $i++ ) {

   // find random length
   $namelength = mt_rand($min_username_length, $max_username_length);
   $passlength = mt_rand($min_password_length, $max_password_length);

   // Get username
   $username = random($namelength);
   $password = random($passlength);

   // Make sure username is unique
   if ( array_key_exists( $username, $users ) == false )
   {
	  // Add to array
	  $users[$username] = $password;
   }
}

echo '<b><center><font color="red">Flines: </font><br /></center></b>';
echo '<br />';
// Print usernames to screen
foreach ( $users as $user => $pass )
{
	echo '<b><center>F: '. $user. ' '. $pass . '<br /></center></b>';
}
echo '<br />';
echo '<b><center><font color="red">Clines: </font><br /></center></b>';
echo '<br />';
foreach ( $users as $user => $pass )
{
	echo '<b><center>C: '. $hosts. ' '. $ports. ' '. $user. ' '. $pass . '<br /></center></b>';
}
echo '<br />';
echo '<br />';
echo '<br />';

}
?>



<!-- end class viewplan -->

</div><!-- end class planinner -->

</div><!-- end class plan nomarginrt floatrt -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class hosting_plans -->


</div><!-- end class box -->



<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id main -->

<div id="top_footer">

<div class="wrapper">

<div class="wrapper">

<div class="footerlt">

<div class="footer_column">


<div class="footer_column">

<h2>Support </h2>

<ul>
<li><a href="contact.php" title="CONTACT"><span id="result_box" lang="fr">CONTACT</span></a></li>
</ul>
</div><!-- end class footer_column -->
<!-- end class footer_column -->
<div class="clear"></div><!-- end class clear -->
<!-- end class socialmedia -->
<div class="payment"></div><!-- end class payment -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id top_footer -->

<div id="bottom_footer">

<div class="wrapper">
  
<div class="left_bottom">

<ul>
<li>
Copyright &copy; <a href="contact.php" title="Contact">Contact</a></li>
<li>
<a href="Skype:vitruvedz?add" title="SKYPE">BY VITRUVEDZ</a></li>
</ul>

</div><!-- end class left_bottom -->

<div class="right_bottom">

<p>&nbsp;</p>

</div><!-- end class right_bottom -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper --> 

</div><!-- end id bottom_footer -->

</div><!-- end id container -->
</body>
</html>