<?php
require("config.php");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $nameserver; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="all,index,nofollow" />
<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />

<link href="styles/style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.coda-slider-2.0.js"></script>
<script type="text/javascript" src="js/jquery.form_validation.js"></script>
<script type="text/javascript" src="js/contact_form.js"></script>

<script type="text/javascript">

$().ready(function() {
 $("#coda-slider-1").codaSlider();
});

</script>

<script src="https://cdn.adf.ly/js/display.js"></script> 
<!--
[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]
-->
</head>
<body>
<!--
This free web hosting template is provided by http://lkgraph.com/
and is released and licensed under the
Creative Commons Attribution 3.0 Unported License (http://creativecommons.org/licenses/by/3.0/).
This means that you are free to download this template for any personal and commercial purpose as long as you
keep the text links in the bottom right footer as they are.
-->
<div id="container">

<div id="top_wrap">

<div id="top_menu">

<div class="ukusa"></div>
<!-- end class ukusa -->
<!-- end class email -->
<div class="phone">

Skype: <a href="Skype:<?php echo $skype; ?>?add" title="Skype"><?php echo $skype; ?></a>
</div>
<!-- end class phone -->

<div class="login">

<a href="contact.php" title="SUPPORT">SUPP</a></div>
<!-- end class login -->

<div class="livechat">

<a href="Skype:<?php echo $skype; ?>?add" title="Live Chat">Live Chat</a></div>
<!-- end class livechat -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end id top_menu -->

</div><!-- end id top_wrap -->

<div id="header_wrap">

<div id="header">

<div class="logo">

<a href="index.php" title="<?php echo $nameserver; ?>"><?php echo $nameserver; ?></a></div>
<!-- end class logo -->

<div id="midmenu">

<ul>
<li><a href="index.php" title="Home" class="home">Home</a></li>
<li class="nobg"><a href="contact.php" title="Contact" class="contactus">Contact </a></li>
</ul>
</div><!-- end id midmenu -->

<div class="clear"></div><!-- end class clear -->

<nav id="dropdown">

<ul>
<li class="active"><a href="#" title="text link"></a></li>
<li><a href="index.php" title="welcome to SERVER EXCHANGE">WELCOME</a></li>
<li><a href="cache.php" title="EXCHANGE CACHE">CACHE</a></li>
<li class="menu-drop"><a href="cccam.php" title="EXCHANGE CCCAM">CCCAM</a></li>
<li><a href="magcamd.php" title="EXCHANGE MGCAMD">MGCAMD</a></li>
<li><a href="profile.php" title="PROFILE">PROFILE</a></li>
<li><a href="tools.php" title="TOOLS">TOOLS</a></li>
<li><a href="contact.php" title="Support">SUPP</a></li>
</ul>

</nav><!-- end id dropdown -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end id header -->

</div><!-- end id header_wrap -->



<div class="slidernavcon coda-nav">

<div class="wrapper">

<ul class="slidernav">

<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->
 
</div><!-- end classes slidernavcon coda-nav -->
 
</div><!-- end class coda-slider-wrapper -->
  
</div><!-- end class bannercon -->

<div id="mainbg">

<div class="wrapper">
<h1>WELCOME IN <?php echo $nameserver; ?> TOOLS</h1>
<div id="post_26">
  <div>
    <h2>SERVER TOOLS</h2>
	<br>
  </div>
  <!-- end class domainarea -->
<div class="hosting_plans">

<div class="plan">

<div class="planinner">

<h2>textmechanic</h2>
<center><img src="images/android-tool.png" alt="Smiley face" height="120" width="120"></center>

<div class="planrate">

<div class="doller1">TOOL</div>
<!-- end class doller1 -->

<div class="numeric1">S</div>
<!-- end class numeric1 -->

<div class="per"></div>
<!-- end class per -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class planrate -->

<div class="viewplan">

<a href="textmechanic/index.php" title="EXCHANGE">USE TOOLS</a></div>
<!-- end class viewplan -->

</div><!-- end class plaininner -->

</div><!-- end class plan -->

<div class="plan">

<div class="planinner">

<h2>tester line</h2>
<center><img src="images/android-tool.png" alt="Smiley face" height="120" width="120"></center>

<div class="planrate">

<div class="doller1">TOOL</div>
<!-- end class doller1 -->

<div class="numeric1">S</div>
<!-- end class numeric1 -->

<div class="per"></div>
<!-- end class per -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class planrate -->

<div class="viewplan">

<a href="" title="EXCHANGE">USE TOOLS</a></div>
<!-- end class viewplan -->

</div><!-- end class planinner -->

</div><!-- end class plan -->

<div class="plan">

<div class="planinner">

<h2>DISABLE BAD CACHE </h2>
<center><img src="images/android-tool.png" alt="Smiley face" height="120" width="120"></center>

<div class="planrate">

<div class="doller1">TOOL</div>
<!-- end class doller1 -->

<div class="numeric1">S</div>
<!-- end class numeric1 -->

<div class="per"></div>
<!-- end class per -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class planrate -->

<div class="viewplan">

<a href="check-cache.php" title="EXCHANGE">USE TOOLS</a></div>
<!-- end class viewplan -->

</div><!-- end class planinner -->

</div><!-- end class plan -->

<div class="plan nomarginrt floatrt">

<div class="planinner">



<h2>generator users</h2>
<center><img src="images/android-tool.png" alt="Smiley face" height="120" width="120"></center>

<div class="planrate">

<div class="doller1">TOOL</div>
<!-- end class doller1 -->

<div class="numeric1">S</div>
<!-- end class numeric1 -->

<div class="per"></div>
<!-- end class per -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class planrate -->

<div class="viewplan">

<a href="tools-generat.php" title="EXCHANGE">USE TOOLS</a></div>

</div>
<!-- end class viewplan -->

</div><!-- end class planinner -->

</div><!-- end class plan nomarginrt floatrt -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class hosting_plans -->


</div><!-- end class box -->



<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id main -->

<div id="top_footer">

<div class="wrapper">

<div class="wrapper">

<div class="footerlt">

<div class="footer_column">


<div class="footer_column">

<h2>Support </h2>

<ul>
<li><a href="contact.php" title="CONTACT"><span id="result_box" lang="fr">CONTACT</span></a></li>
</ul>
</div><!-- end class footer_column -->
<!-- end class footer_column -->
<div class="clear"></div><!-- end class clear -->
<!-- end class socialmedia -->
<div class="payment"></div><!-- end class payment -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class footerlt -->
<!-- end class footer_right -->
<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper -->

</div><!-- end id top_footer -->

<div id="bottom_footer">

<div class="wrapper">
  
<div class="left_bottom">

<ul>
<li>
Copyright &copy; <a href="contact.php" title="Contact">Contact</a></li>
<li>
<a href="Skype:vitruvedz?add" title="SKYPE">BY VITRUVEDZ</a></li>
</ul>

</div><!-- end class left_bottom -->

<div class="right_bottom">

<p>&nbsp;</p>

</div><!-- end class right_bottom -->

<div class="clear"></div><!-- end class clear -->

</div><!-- end class wrapper --> 

</div><!-- end id bottom_footer -->

</div><!-- end id container -->
</body>
</html>