$('input#mybip').on('focusout', function() {
    var host = $('input#mybip').val();
    if ($.trim(host) != '') {
         $.post('ip.php', {host: host}, function(data) {
            $('input[name="ip"]').val(data);
         
        })
     
    };

});